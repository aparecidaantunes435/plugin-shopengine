<?php

namespace ShopEngine\Core\Register;

class Base {

}
